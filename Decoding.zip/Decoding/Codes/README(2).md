# Project 1: Decoding Parameter & Sampling Analysis

**Course:** Special Topics in AI (MS AI)

This project runs local benchmarks with **Ollama** on two model architectures (**Llama 3.2** and **Qwen 2.5**). It measures how three decoding settings, **Temperature**, **Top-K** and **Top-P**, affect:

1. **Output determinism**: does the same prompt give the same answer every time?
2. **Hallucination**: does the model invent facts?
3. **Structure**: does the model follow a required output format (JSON, exact list, one word)?

---

## 1. Description

### Libraries

| Library | Purpose |
|---|---|
| `ollama` (Python client) | Send prompts to local models with custom decoding options |
| `pandas` | Store results and aggregate the metrics |
| `matplotlib` | Charts for the report |
| `numpy` | Numerical helpers |
| `tqdm` | Progress bar and ETA during the benchmark |
| `json`, `re`, `difflib`, `csv` (standard library) | JSON validation, pattern checks, text similarity, saving results |

### Models

| Model | Family / architecture | Size |
|---|---|---|
| `llama3.2:1b` | Meta Llama 3 family | 1.2B parameters |
| `qwen2.5:1.5b` | Alibaba Qwen 2.5 family | 1.5B parameters |

Both models are of similar size, so differences come mainly from architecture and training. Both run on a normal laptop CPU.

### Experimental design (One-Factor-at-a-Time)

The Ollama defaults are the baseline (**Temperature 0.8, Top-K 40, Top-P 0.9**). Each experiment changes one parameter and keeps the other two at the baseline.

| Experiment | Varied | Values | Fixed |
|---|---|---|---|
| 1. Temperature | temperature | 0, 0.4, 0.8, 1.2, 1.6 | top_k 40, top_p 0.9 |
| 2. Top-K | top_k | 1, 10, 40, 100 | temp 0.8, top_p 0.9 |
| 3. Top-P | top_p | 0.1, 0.5, 0.9, 1.0 | temp 0.8, top_k 40 |
| 4. Interaction | temp × top_p | {0.2, 1.2} × {0.3, 1.0} | top_k 40 |

- **Unique settings:** 15. The baseline appears in experiments 1–3 but is run only once.
- **Prompts:** 12 fixed prompts in 3 categories (see `config.py`).
- **Repeats:** 5 per prompt per setting.
- **Total:** 2 models × 15 settings × 12 prompts × 5 repeats = **1,800 generations**.

**Controls:**
- The same prompts are used for every setting and model.
- `num_predict=200`, `repeat_penalty=1.1` and `min_p=0` are fixed for both models.
- No `seed` is set, because a fixed seed would make all runs identical and hide the effect being measured.
- Top-K and Top-P are tested at temperature 0.8. At temperature 0 the model always picks the top token, so Top-K and Top-P would have no effect.

### Prompt set (12)

| Category | Prompts | What is measured |
|---|---|---|
| Determinism (3) | Open-ended: explain a neural network, coffee-shop slogan, language tips | Similarity of the 5 repeated answers |
| Hallucination (5) | 3 real facts (capital of Australia, author of *Pride and Prejudice*, boiling point of water) and 2 fake questions (a non-existent paper, a non-existent "Nobel Prize in Robotics") | Factual accuracy; refusal vs. invention on fake questions |
| Structure (4) | JSON object, JSON list of 3, numbered list of exactly 5, one-word Yes/No | Strict and lenient format compliance |

### Metrics

| Metric | How it is computed |
|---|---|
| Mean similarity | Average `difflib.SequenceMatcher` ratio over all pairs of the 5 answers (1 = identical) |
| Unique answers | Number of distinct answers out of 5 |
| Factual accuracy | % of answers containing the correct keyword |
| Hallucination rate | % of fake-question answers that invent content. Each answer is classified as: **admitted unknown** ("there is no…", "could not find…"), **generic refusal** ("I can't assist with that"), **mixed** (rejects the premise but also invents facts) or **fabricated** (answers as if the entity were real). Hallucination = mixed + fabricated |
| Strict structure | % of answers that are exactly the requested format (e.g. `json.loads` works on the raw output) |
| Lenient structure | % where the requested content is present, even with extra text or ``` fences |

### Expected results (hypotheses)

1. **Temperature:**
   - Low temperature (0–0.4) gives near-identical answers, the highest JSON and format compliance, and the lowest hallucination rate.
   - As temperature rises above 1.0, similarity drops, format errors increase and hallucination on fake questions rises.
2. **Top-K:**
   - Top-K = 1 behaves like greedy decoding, so it should be fully deterministic.
   - Larger K adds diversity. The effect should flatten above about 40, since few tokens beyond that carry real probability.
3. **Top-P:**
   - Low Top-P (0.1) keeps only the most likely tokens, which makes the output more deterministic and more structured.
   - Top-P of 0.9–1.0 behaves close to the baseline.
4. **Interaction:** a low Top-P (0.3) should largely cancel the randomness of a high temperature (1.2), because it cuts off the low-probability tail that high temperature boosts.
5. **Models:**
   - Qwen 2.5 is expected to follow strict JSON formats more reliably.
   - Llama 3.2 is expected to produce longer, more conversational answers and to break strict formats more often at high temperature.
   - Both models should answer the easy factual questions correctly at low temperature.

---

## 2. Setup (VS Code)

1. **Install Ollama:** download it from https://ollama.com/download and open the app. It runs in the background.
2. **Download the models.** Open a terminal and run:
   ```bash
   ollama pull llama3.2:1b
   ollama pull qwen2.5:1.5b
   ```
3. **Install Python 3.10+** and the **Python** extension in VS Code.
4. **Open this folder in VS Code** (File → Open Folder), then open a terminal (Terminal → New Terminal) and run:
   ```bash
   # Windows
   python -m venv .venv
   .venv\Scripts\activate

   # macOS / Linux
   python3 -m venv .venv
   source .venv/bin/activate

   pip install -r requirements.txt
   ```

## 3. Run

```bash
python config.py            # print the plan (1,800 calls)
python benchmark.py --pilot # 60 calls: checks everything works and estimates total time
python benchmark.py         # full benchmark -> results/raw_results.csv
python analyze.py           # tables + charts -> results/ and results/figures/
python make_examples.py     # real answers, per question and setting -> results/answer_examples.md
```

- **Resume:** every answer is saved immediately. If the run stops (Ctrl+C, sleep, crash), run `python benchmark.py` again and it continues where it left off.
- **Splitting work in a group:** each member runs one model, then you merge the files.
  ```bash
  python benchmark.py --models llama3.2:1b --out results/llama.csv
  python benchmark.py --models qwen2.5:1.5b --out results/qwen.csv
  ```
  Merge `results/llama.csv` and `results/qwen.csv` into `results/raw_results.csv` (same header, append rows), then run `analyze.py`.
- **Pipeline test without Ollama:** `python benchmark.py --mock`, then `python analyze.py --input results/mock_results.csv --outdir results_mock`. Mock answers are simulated. **Do not use them in the report.**

## 4. Outputs

| File | Content |
|---|---|
| `results/raw_results.csv` | Every model answer with its settings, tokens/sec and latency |
| `results/scored_results.csv` | Every answer with its scores |
| `results/summary_by_setting.csv` | All metrics per model × setting |
| `results/summary_<experiment>.csv` | One table per experiment |
| `results/summary_tables.md` | The same tables in Markdown, ready for the report |
| `results/manual_check_sample.csv` | 40 random answers for manual verification of the automatic scoring |
| `results/hallucination_breakdown.csv` | Fake-question outcomes per model and prompt |
| `results/fake_answers_review.csv` | Every fake-question answer with its label (for manual review) |
| `results/answer_examples.md` | Readable examples: each question, the setting, and the models' real answers |
| `results/fake_labels_manual.csv` | Manually reviewed labels for all 300 fake-question answers (used by `analyze.py` when present) |
| `results/figures/fig1_temperature.png` | Effect of temperature (4 panels) |
| `results/figures/fig2_top_k.png` | Effect of Top-K |
| `results/figures/fig3_top_p.png` | Effect of Top-P |
| `results/figures/fig4_interaction.png` | Temperature × Top-P heatmaps |
| `results/figures/fig5_model_comparison.png` | Llama vs. Qwen overall |
| `results/figures/fig6_hallucination_breakdown.png` | What each model did on fake questions, per temperature |

## 5. Project structure

```
decoding-analysis/
├── config.py         # models, settings, 12 prompts
├── benchmark.py      # runs the models, saves raw answers
├── metrics.py        # scoring: similarity, hallucination, structure
├── analyze.py        # aggregation, tables, charts
├── make_examples.py  # readable file of real answers per question and setting
├── requirements.txt
├── report/           # final PDF report goes here
└── results/          # generated data and figures
```

## 6. Limitations

- Hallucination is first labelled automatically with keyword heuristics. All 300 fake-question answers were then reviewed by hand; the reviewed labels (`results/fake_labels_manual.csv`) override the automatic ones. The automatic labels agreed with the reviewed labels on 94.3% of answers (97.3% on hallucination yes/no). The keywords were refined on this same data, so this agreement is optimistic.
- 12 prompts and 5 repeats are enough to show trends, but not to make strong statistical claims.
- Only small (1–1.5B) models were tested. Larger models may hallucinate less.
- String similarity measures surface wording, not meaning. Two answers with the same meaning but different words score lower.

**Hardware used:** _fill in: CPU / GPU / RAM / OS_
