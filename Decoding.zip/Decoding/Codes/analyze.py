"""
Analyze benchmark results: score every answer, aggregate, and draw charts.

Usage:
    python analyze.py                                  # uses results/raw_results.csv
    python analyze.py --input results/pilot_results.csv
    python analyze.py --input results/mock_results.csv --outdir results_mock

Outputs (in --outdir, default "results"):
    scored_results.csv        every answer with its scores
    determinism_groups.csv    similarity / unique answers per (model, setting, prompt)
    summary_by_setting.csv    all metrics per (model, setting)
    summary_<experiment>.csv  one table per experiment
    summary_tables.md         the same tables in Markdown (paste into the report)
    manual_check_sample.csv   random answers to verify the automatic scoring by hand
    figures/*.png             charts for the report
"""

import argparse
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap

import config
import metrics

# --------------------------------------------------------------------------
# Chart style (light theme, colour-blind-checked categorical pair)
# --------------------------------------------------------------------------
SERIES_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]  # fixed order: model 1, 2, ...
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
GRID, AXIS, SURFACE = "#e1e0d9", "#c3c2b7", "#fcfcfb"
SEQ = LinearSegmentedColormap.from_list("blue", ["#cde2fb", "#86b6ef", "#2a78d6", "#184f95", "#0d366b"])
MARKERS = ["o", "s", "D", "^"]

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "axes.edgecolor": AXIS, "axes.labelcolor": INK2, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "axes.spines.top": False, "axes.spines.right": False,
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "legend.frameon": False,
})

METRIC_LABELS = {
    "det_similarity": "Determinism: mean similarity (open prompts)",
    "det_unique": "Unique answers out of 5 (open prompts)",
    "all_similarity": "Mean similarity (all 12 prompts)",
    "fact_accuracy": "Factual accuracy (%)",
    "hallucination_rate": "Hallucination rate on fake questions (%)",
    "struct_strict": "Structure: strict format compliance (%)",
    "struct_lenient": "Structure: lenient compliance (%)",
    "avg_words": "Average answer length (words)",
    "tokens_per_sec": "Speed (tokens/sec)",
}
PCT = ["fact_accuracy", "hallucination_rate", "struct_strict", "struct_lenient"]


# --------------------------------------------------------------------------
def load(path):
    df = pd.read_csv(path, keep_default_na=False, na_values=[])
    df["error"] = df["error"].astype(str)
    bad = df["error"].str.len() > 0
    if bad.any():
        print(f"Skipping {bad.sum()} rows with errors.")
    df = df[~bad].copy()
    df["temperature"] = df["temperature"].astype(float).round(2)
    df["top_k"] = df["top_k"].astype(int)
    df["top_p"] = df["top_p"].astype(float).round(2)
    for c in ["eval_tokens", "tokens_per_sec", "latency_s"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["response"] = df["response"].astype(str)
    return df


def score(df):
    scores = pd.DataFrame([metrics.score_row(r) for r in df.to_dict("records")], index=df.index)
    return pd.concat([df, scores], axis=1)


LABEL_KEYS = ["model", "temperature", "top_k", "top_p", "prompt_id", "run"]


def apply_manual_labels(df, path):
    """Replace the automatic fake-question labels with manually reviewed ones (if the file exists)."""
    if not os.path.exists(path):
        print("No manual labels file found - using automatic hallucination labels.")
        return df
    lab = pd.read_csv(path)
    lab["temperature"] = lab["temperature"].astype(float).round(2)
    lab["top_p"] = lab["top_p"].astype(float).round(2)
    lab["top_k"] = lab["top_k"].astype(int)
    lab["run"] = lab["run"].astype(int)
    df = df.copy()
    df["run"] = df["run"].astype(int)
    df = df.merge(lab[LABEL_KEYS + ["manual_label"]], on=LABEL_KEYS, how="left")
    fake = df["type"] == "fake"
    df.loc[fake, "auto_outcome"] = df.loc[fake, "fake_outcome"]
    has = fake & df["manual_label"].notna()
    agree = (df.loc[has, "auto_outcome"] == df.loc[has, "manual_label"]).mean()
    hall = lambda s: s.isin(["mixed", "fabricated"])
    agree_h = (hall(df.loc[has, "auto_outcome"]) == hall(df.loc[has, "manual_label"])).mean()
    df.loc[has, "fake_outcome"] = df.loc[has, "manual_label"]
    df.loc[has, "hallucinated"] = hall(df.loc[has, "manual_label"]).astype(int)
    df.loc[has, "refused"] = 1 - df.loc[has, "hallucinated"]
    print(f"Manual labels applied to {has.sum()} of {fake.sum()} fake-question answers "
          f"(automatic vs manual: {agree:.1%} exact agreement, {agree_h:.1%} on hallucination yes/no).")
    return df


def determinism_table(df):
    keys = ["model", "temperature", "top_k", "top_p", "prompt_id", "category"]
    rows = []
    for k, g in df.groupby(keys, sort=False):
        d = metrics.determinism_scores(g.sort_values("run")["response"].tolist())
        rows.append(dict(zip(keys, k), **d))
    return pd.DataFrame(rows)


def summarize(df, det):
    keys = ["model", "temperature", "top_k", "top_p"]
    det_groups = {k: g for k, g in det.groupby(keys, sort=False)}
    rows = []
    for k, g in df.groupby(keys, sort=False):
        dg = det_groups[k]
        open_ = dg[dg["category"] == "determinism"]
        rows.append({
            **dict(zip(keys, k)),
            "det_similarity": open_["mean_similarity"].mean(),
            "det_unique": open_["unique_answers"].mean(),
            "all_similarity": dg["mean_similarity"].mean(),
            "fact_accuracy": 100 * g["fact_correct"].dropna().astype(float).mean(),
            "hallucination_rate": 100 * g["hallucinated"].dropna().astype(float).mean(),
            **{f"fake_{o}": 100 * (g.loc[g["type"] == "fake", "fake_outcome"] == o).mean()
               for o in metrics.FAKE_OUTCOMES},
            "struct_strict": 100 * g["struct_strict"].dropna().astype(float).mean(),
            "struct_lenient": 100 * g["struct_lenient"].dropna().astype(float).mean(),
            "avg_words": g["words"].mean(),
            "tokens_per_sec": g["tokens_per_sec"].mean(),
            "n_answers": len(g),
        })
    return pd.DataFrame(rows).round(3)


def experiment_table(summary, settings):
    keys = [config.setting_key(*s) for s in settings]
    s = summary.copy()
    s["_key"] = list(zip(s["temperature"], s["top_k"], s["top_p"]))
    s = s[s["_key"].isin(keys)].copy()
    s["_order"] = s["_key"].map({k: i for i, k in enumerate(keys)})
    return s.sort_values(["model", "_order"]).drop(columns=["_key", "_order"])


# --------------------------------------------------------------------------
# Charts
# --------------------------------------------------------------------------
def _fmt_ax(ax, metric):
    if metric in PCT:
        ax.set_ylim(-5, 105)
        ax.set_yticks([0, 25, 50, 75, 100])
    elif metric in ("det_similarity", "all_similarity"):
        ax.set_ylim(-0.05, 1.05)
    ax.tick_params(length=0)


def sweep_figure(table, param, title, path, models):
    panel_metrics = ["det_similarity", "fact_accuracy", "hallucination_rate", "struct_strict"]
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.2))
    values = list(dict.fromkeys(table[param].tolist()))
    categorical = param == "top_k"  # 1,10,40,100 are not evenly spaced
    xpos = {v: (i if categorical else v) for i, v in enumerate(values)}
    for ax, m in zip(axes.flat, panel_metrics):
        ends = []
        for i, model in enumerate(models):
            sub = table[table["model"] == model]
            if sub.empty:
                continue
            x = [xpos[v] for v in sub[param]]
            ax.plot(x, sub[m], color=SERIES_COLORS[i % 4], lw=2, marker=MARKERS[i % 4],
                    ms=7, mec=SURFACE, mew=1.5, label=model)
            ends.append([sub[m].iloc[-1], x[-1], model.split(":")[0]])
        # direct labels at line ends, nudged apart so they never overlap
        span = 1.1 if m in ("det_similarity", "all_similarity") else 110
        ends = [e for e in ends if pd.notna(e[0])]
        ends.sort(key=lambda e: e[0])
        for a, b in zip(ends, ends[1:]):
            if b[0] - a[0] < 0.06 * span:
                b[0] = a[0] + 0.06 * span
        for y, x_last, name in ends:
            ax.annotate(name, (x_last, y), xytext=(8, 0), textcoords="offset points",
                        va="center", fontsize=8, color=INK2)
        ax.set_title(METRIC_LABELS[m], loc="left", fontsize=10)
        ax.set_xlabel(param.replace("_", "-").title() if param != "top_k" else "Top-K")
        if categorical:
            ax.set_xticks(range(len(values)), [str(v) for v in values])
        else:
            ax.set_xticks(values)
        ax.margins(x=0.12)
        _fmt_ax(ax, m)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper right", ncol=len(models), bbox_to_anchor=(0.98, 0.99))
    fig.suptitle(title, x=0.02, ha="left", fontsize=13, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(path, dpi=160)
    plt.close(fig)


def interaction_figure(table, path, models):
    panel_metrics = ["det_similarity", "hallucination_rate", "struct_strict"]
    temps = sorted(table["temperature"].unique())
    tops = sorted(table["top_p"].unique())
    fig, axes = plt.subplots(len(models), len(panel_metrics), figsize=(11, 3.4 * len(models)), squeeze=False)
    for r, model in enumerate(models):
        sub = table[table["model"] == model]
        for c, m in enumerate(panel_metrics):
            ax = axes[r][c]
            grid = np.full((len(temps), len(tops)), np.nan)
            for _, row in sub.iterrows():
                grid[temps.index(row["temperature"]), tops.index(row["top_p"])] = row[m]
            vmax = 1 if m == "det_similarity" else 100
            ax.imshow(grid, cmap=SEQ, vmin=0, vmax=vmax, aspect="auto")
            for i in range(len(temps)):
                for j in range(len(tops)):
                    v = grid[i, j]
                    if np.isnan(v):
                        continue
                    txt = f"{v:.2f}" if m == "det_similarity" else f"{v:.0f}%"
                    ax.text(j, i, txt, ha="center", va="center", fontsize=11, fontweight="bold",
                            color="white" if v / vmax > 0.55 else INK)
            ax.set_xticks(range(len(tops)), [f"top-p {t}" for t in tops])
            ax.set_yticks(range(len(temps)), [f"temp {t}" for t in temps])
            ax.grid(False)
            ax.tick_params(length=0)
            for s in ax.spines.values():
                s.set_visible(False)
            ax.set_title(f"{model}\n{METRIC_LABELS[m]}", loc="left", fontsize=9)
    fig.suptitle("Interaction: Temperature x Top-P (Top-K = 40)", x=0.02, ha="left",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(path, dpi=160)
    plt.close(fig)


def model_comparison_figure(summary, path, models):
    s = summary.copy()
    s["no_hallucination"] = 100 - s["hallucination_rate"]
    s["det_pct"] = 100 * s["det_similarity"]
    cols = [("det_pct", "Determinism\n(similarity x100)"), ("fact_accuracy", "Factual\naccuracy"),
            ("no_hallucination", "Refused fake\nquestions"), ("struct_strict", "Strict\nstructure"),
            ("struct_lenient", "Lenient\nstructure")]
    means = s.groupby("model")[[c for c, _ in cols]].mean()
    fig, ax = plt.subplots(figsize=(10, 4.6))
    n = len(models)
    width = 0.8 / n
    x = np.arange(len(cols))
    for i, model in enumerate(models):
        if model not in means.index:
            continue
        vals = means.loc[model].values
        bars = ax.bar(x + (i - (n - 1) / 2) * width, vals, width * 0.92, color=SERIES_COLORS[i % 4],
                      label=model, edgecolor=SURFACE, linewidth=2)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, v + 1.5, f"{v:.0f}", ha="center", fontsize=8, color=INK2)
    ax.set_xticks(x, [label for _, label in cols])
    ax.set_ylim(0, 110)
    ax.set_ylabel("Score (higher is better)")
    ax.tick_params(length=0)
    ax.grid(axis="x", visible=False)
    ax.legend(loc="upper right", ncol=n, bbox_to_anchor=(1, 1.12))
    ax.set_title("Model comparison (average over all 15 settings)", loc="left", fontsize=13, pad=22)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


OUTCOME_STYLE = {  # reserved status colours: good / neutral / warning / critical
    "admitted_unknown": ("Says it does not exist", "#0ca30c"),
    "generic_refusal": ("Generic refusal", "#898781"),
    "mixed": ("Rejects premise + invents facts", "#fab219"),
    "fabricated": ("Fully fabricated", "#d03b3b"),
}


def outcome_figure(table, path, models):
    """100% stacked bars: what each model did on the fake questions, per temperature."""
    temps = list(dict.fromkeys(table["temperature"].tolist()))
    fig, axes = plt.subplots(1, len(models), figsize=(5.2 * len(models), 4.6), squeeze=False, sharey=True)
    for ax, model in zip(axes[0], models):
        sub = table[table["model"] == model].set_index("temperature").reindex(temps)
        bottom = np.zeros(len(temps))
        x = np.arange(len(temps))
        for o in metrics.FAKE_OUTCOMES:
            label, color = OUTCOME_STYLE[o]
            vals = sub[f"fake_{o}"].fillna(0).values
            ax.bar(x, vals, 0.62, bottom=bottom, color=color, edgecolor=SURFACE, linewidth=2, label=label)
            for xi, v, b in zip(x, vals, bottom):
                if v >= 10:
                    ax.text(xi, b + v / 2, f"{v:.0f}%", ha="center", va="center", fontsize=8,
                            color="white" if o in ("fabricated", "admitted_unknown") else INK)
            bottom += vals
        ax.set_xticks(x, [str(t) for t in temps])
        ax.set_xlabel("Temperature")
        ax.set_ylim(0, 100)
        ax.set_title(model, loc="left", fontsize=11)
        ax.grid(axis="x", visible=False)
        ax.tick_params(length=0)
    axes[0][0].set_ylabel("Share of answers to fake questions (%)")
    handles, labels = axes[0][0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, bbox_to_anchor=(0.5, 0.92), fontsize=9)
    fig.suptitle("What the models did when asked about things that do not exist",
                 x=0.02, ha="left", fontsize=13, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.89))
    fig.savefig(path, dpi=160)
    plt.close(fig)


# --------------------------------------------------------------------------
def to_markdown(df):
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            v = r[c]
            cells.append(f"{v:.2f}" if isinstance(v, float) else str(v))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", default="results/raw_results.csv")
    ap.add_argument("--outdir", default="results")
    args = ap.parse_args()

    figdir = os.path.join(args.outdir, "figures")
    os.makedirs(figdir, exist_ok=True)

    df = score(load(args.input))
    df = apply_manual_labels(df, os.path.join(os.path.dirname(args.input) or ".", "fake_labels_manual.csv"))
    models = [m for m in config.MODELS if m in df["model"].unique()] + \
             [m for m in df["model"].unique() if m not in config.MODELS]
    print(f"Loaded {len(df)} answers | models: {models}")

    det = determinism_table(df)
    summary = summarize(df, det)

    df.to_csv(os.path.join(args.outdir, "scored_results.csv"), index=False)
    det.round(3).to_csv(os.path.join(args.outdir, "determinism_groups.csv"), index=False)
    summary.to_csv(os.path.join(args.outdir, "summary_by_setting.csv"), index=False)

    show = ["model", "temperature", "top_k", "top_p", "det_similarity", "det_unique",
            "fact_accuracy", "hallucination_rate", "struct_strict", "struct_lenient", "avg_words"]
    md = ["# Summary tables\n",
          "det_similarity: 1 = identical answers across 5 runs. det_unique: distinct answers out of 5.",
          "fact_accuracy / hallucination_rate / struct_*: percentages.\n"]

    exps = config.experiment_settings()
    titles = {"temperature": "Effect of Temperature (Top-K = 40, Top-P = 0.9)",
              "top_k": "Effect of Top-K (Temperature = 0.8, Top-P = 0.9)",
              "top_p": "Effect of Top-P (Temperature = 0.8, Top-K = 40)"}
    params = {"temperature": "temperature", "top_k": "top_k", "top_p": "top_p"}
    for n, (name, settings) in enumerate(exps.items(), start=1):
        table = experiment_table(summary, settings)
        if table.empty:
            continue
        table.to_csv(os.path.join(args.outdir, f"summary_{name}.csv"), index=False)
        md.append(f"## Experiment {n}: {name}\n")
        md.append(to_markdown(table[show]) + "\n")
        if name == "interaction":
            if table.groupby("model").size().min() >= 4:
                interaction_figure(table, os.path.join(figdir, f"fig{n}_interaction.png"), models)
        elif table.groupby("model").size().min() >= 2:
            sweep_figure(table, params[name], titles[name],
                         os.path.join(figdir, f"fig{n}_{name}.png"), models)

    if summary["model"].nunique() >= 1 and len(summary) > 1:
        model_comparison_figure(summary, os.path.join(figdir, "fig5_model_comparison.png"), models)
    temp_table = experiment_table(summary, exps["temperature"])
    if not temp_table.empty and temp_table.groupby("model").size().min() >= 2:
        outcome_figure(temp_table, os.path.join(figdir, "fig6_hallucination_breakdown.png"), models)

    # Hallucination outcome breakdown (all settings)
    fake = df[df["type"] == "fake"]
    breakdown = (pd.crosstab([fake["model"], fake["prompt_id"]], fake["fake_outcome"], normalize="index")
                 .reindex(columns=metrics.FAKE_OUTCOMES, fill_value=0) * 100).round(1).reset_index()
    breakdown.to_csv(os.path.join(args.outdir, "hallucination_breakdown.csv"), index=False)
    md.append("## Fake-question outcomes (all settings, % of answers)\n")
    md.append(to_markdown(breakdown) + "\n")
    # every fake-question answer with its label, for manual verification
    fake[["model", "temperature", "top_k", "top_p", "prompt_id", "run", "fake_outcome", "response"]] \
        .to_csv(os.path.join(args.outdir, "fake_answers_review.csv"), index=False)
    overall = summary.groupby("model")[["det_similarity", "fact_accuracy", "hallucination_rate",
                                         "struct_strict", "struct_lenient", "avg_words",
                                         "tokens_per_sec"]].mean().round(2).reset_index()
    md.append("## Overall model comparison (mean over all settings)\n")
    md.append(to_markdown(overall) + "\n")
    with open(os.path.join(args.outdir, "summary_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md))

    # Random sample of fake/fact/structure answers to check the automatic scoring by hand
    check = df[df["type"].isin(["fake", "fact", "json_object", "numbered_list"])]
    sample = check.sample(min(40, len(check)), random_state=1)[
        ["model", "temperature", "top_k", "top_p", "prompt_id", "response",
         "fact_correct", "fake_outcome", "hallucinated", "struct_strict", "struct_lenient"]]
    sample.assign(manual_label="").to_csv(os.path.join(args.outdir, "manual_check_sample.csv"), index=False)

    print("\nOverall (mean over all settings):")
    print(overall.to_string(index=False))
    print("\nFake-question outcomes (% of answers, all settings):")
    print(breakdown.to_string(index=False))
    print(f"\nTables + charts written to: {os.path.abspath(args.outdir)}")


if __name__ == "__main__":
    main()
