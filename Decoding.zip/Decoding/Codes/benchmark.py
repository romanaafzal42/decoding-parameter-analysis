"""
Run the decoding-parameter benchmark against local Ollama models.

Usage (from the project folder, with Ollama running):
    python benchmark.py --pilot      # 60 calls: 1 model, baseline setting, ETA for full run
    python benchmark.py              # full run (1,800 calls), resumes if interrupted
    python benchmark.py --models qwen2.5:3b     # run only one model (e.g. split in a group)
    python benchmark.py --mock       # fake answers, ONLY to test the pipeline without Ollama

Every answer is appended to a CSV immediately, so if the run stops
(laptop sleeps, Ctrl+C) just run the same command again and it continues.
"""

import argparse
import csv
import os
import random
import sys
import time

from tqdm import tqdm

import config

FIELDS = [
    "model", "temperature", "top_k", "top_p", "prompt_id", "category", "type",
    "run", "response", "eval_tokens", "tokens_per_sec", "latency_s", "error",
]


def _get(obj, key, default=None):
    """Read a field from an Ollama response (works for dicts and objects)."""
    try:
        return obj[key]
    except (KeyError, TypeError, IndexError):
        return getattr(obj, key, default)


# ---------------------------------------------------------------------------
# Ollama client helpers
# ---------------------------------------------------------------------------
def make_client(host):
    import ollama
    client = ollama.Client(host=host)
    try:
        client.list()
    except Exception as e:  # server not running
        sys.exit(
            f"\n[ERROR] Cannot reach Ollama at {host}\n  ({e})\n"
            "  -> Open the Ollama app (or run 'ollama serve') and try again.\n"
        )
    return client


def ensure_model(client, model):
    """Pull the model if it is not downloaded yet."""
    import ollama
    try:
        client.show(model)
    except ollama.ResponseError:
        print(f"Model '{model}' not found locally - pulling it (one-time download)...")
        client.pull(model)


def warm_up(client, model):
    """Load the model into memory so the first timed call is not slower."""
    client.chat(model=model, messages=[{"role": "user", "content": "Hi"}],
                options={"num_predict": 1}, keep_alive="15m")


def ask(client, model, prompt, t, k, p):
    options = dict(config.FIXED_OPTIONS, temperature=t, top_k=k, top_p=p)
    start = time.perf_counter()
    resp = client.chat(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        options=options,
        keep_alive="15m",
    )
    latency = time.perf_counter() - start
    text = _get(_get(resp, "message"), "content", "") or ""
    eval_count = _get(resp, "eval_count") or 0
    eval_ns = _get(resp, "eval_duration") or 0
    tps = eval_count / (eval_ns / 1e9) if eval_ns else 0.0
    return text, eval_count, round(tps, 2), round(latency, 3)


# ---------------------------------------------------------------------------
# Mock client - simulated answers so the analysis code can be tested
# without Ollama. NEVER use mock results in the report.
# ---------------------------------------------------------------------------
class MockClient:
    GOOD = {
        "det_neural_net": "A neural network is a model made of layers of connected nodes. It learns patterns from data by adjusting weights.",
        "det_slogan": "Brewing happiness, one cup at a time.",
        "det_language_tips": "1. Practice daily. 2. Speak with natives. 3. Learn common words first.",
        "fact_australia": "The capital of Australia is Canberra.",
        "fact_austen": "Pride and Prejudice was written by Jane Austen.",
        "fact_boiling": "Water boils at 100 degrees Celsius at sea level.",
        "fake_paper": "I could not find any record of a 2019 paper by Dr. Hamid Zafarov on that topic.",
        "fake_nobel": "There is no Nobel Prize in Robotics, so nobody won it in 1987.",
        "struct_json_object": '{"name": "Ali", "age": 28, "city": "Lahore"}',
        "struct_json_list": '["apple", "banana", "mango"]',
        "struct_numbered_list": "1. Python\n2. Java\n3. C++\n4. JavaScript\n5. Go",
        "struct_one_word": "Yes",
    }
    BAD = {
        "fact_australia": ["The capital of Australia is Sydney."],
        "fact_austen": ["Pride and Prejudice was written by Charlotte Bronte."],
        "fact_boiling": ["Water boils at 90 degrees Celsius at sea level."],
        "fake_paper": ["Dr. Zafarov's 2019 paper proposed quantum-entangled signals for trains, cutting delays by 40%."],
        "fake_nobel": ["The 1987 Nobel Prize in Robotics went to Dr. Hiroshi Tanaka for robotic arms."],
        "struct_json_object": ['Sure! Here is the JSON: {"name": "Ali", "age": 28, "city": "Lahore"}',
                               '{"name": "Ali", "age": 28, "location": "Lahore"}',
                               '{"name": "Ali", "age": 28, "city": "Lahore"'],
        "struct_json_list": ['```json\n["apple", "banana", "mango"]\n```', "apple, banana, mango"],
        "struct_numbered_list": ["Here are some:\n1. Python\n2. Java\n3. C++\n4. Rust\n5. Go\n6. Ruby"],
        "struct_one_word": ["Yes, Python is a programming language."],
    }

    def chat(self, model, messages, options, keep_alive=None):
        prompt = messages[0]["content"]
        pid = next(p["id"] for p in config.PROMPTS if p["prompt"] == prompt)
        t, k, p = options["temperature"], options["top_k"], options["top_p"]
        # randomness grows with temperature, shrinks with low top_k / top_p
        r = (t / 1.6) * (0 if k == 1 else min(1.0, (k / 40) ** 0.3)) * p
        bias = 0.85 if model.startswith("qwen") and pid.startswith("struct") else 1.0
        text = self.GOOD[pid]
        if random.random() < 0.6 * r * bias:
            if pid in self.BAD and random.random() < 0.6:
                text = random.choice(self.BAD[pid])
            else:
                text = text + random.choice(["", " Indeed.", " Hope this helps!", " :)"]) + f" ({random.randint(1, 999)})"
        time.sleep(0.001)
        n = len(text.split())
        return {"message": {"content": text}, "eval_count": n, "eval_duration": int(n * 2e7)}


# ---------------------------------------------------------------------------
def load_done(path):
    """Keys of rows already saved (for resuming)."""
    done = set()
    if os.path.exists(path):
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("error"):
                    continue  # retry failed calls
                key = (row["model"], *config.setting_key(row["temperature"], row["top_k"], row["top_p"]),
                       row["prompt_id"], int(row["run"]))
                done.add(key)
    return done


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--models", nargs="+", default=config.MODELS, help="models to run")
    ap.add_argument("--repeats", type=int, default=config.REPEATS)
    ap.add_argument("--pilot", action="store_true", help="60-call test run + time estimate")
    ap.add_argument("--mock", action="store_true", help="simulated answers (pipeline test only)")
    ap.add_argument("--out", default=None, help="output CSV path")
    ap.add_argument("--host", default=os.environ.get("OLLAMA_HOST", "http://localhost:11434"))
    args = ap.parse_args()

    settings = config.all_settings()
    models = args.models
    if args.pilot:
        b = config.BASELINE
        settings = [config.setting_key(b["temperature"], b["top_k"], b["top_p"])]
        models = models[:1]

    default_out = ("results/mock_results.csv" if args.mock
                   else "results/pilot_results.csv" if args.pilot
                   else "results/raw_results.csv")
    out_path = args.out or default_out
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)

    client = MockClient() if args.mock else make_client(args.host)

    done = load_done(out_path)
    jobs = [(m, s, pr, r) for m in models for s in settings
            for pr in config.PROMPTS for r in range(1, args.repeats + 1)]
    todo = [j for j in jobs if (j[0], *j[1], j[2]["id"], j[3]) not in done]

    print(f"Models: {models}")
    print(f"Settings: {len(settings)} | Prompts: {len(config.PROMPTS)} | Repeats: {args.repeats}")
    print(f"Total calls: {len(jobs)} | Already done: {len(jobs) - len(todo)} | To run: {len(todo)}")
    print(f"Saving to: {out_path}\n")
    if not todo:
        print("Nothing to do - all results already saved.")
        return

    new_file = not os.path.exists(out_path) or os.path.getsize(out_path) == 0
    f = open(out_path, "a", newline="", encoding="utf-8")
    writer = csv.DictWriter(f, fieldnames=FIELDS)
    if new_file:
        writer.writeheader()

    current_model = None
    t0 = time.perf_counter()
    errors = 0
    call_time = 0.0   # time spent inside model calls only (excludes download/warm-up)
    try:
        for model, (t, k, p), pr, run in tqdm(todo, unit="call"):
            if model != current_model and not args.mock:
                ensure_model(client, model)
                warm_up(client, model)
                current_model = model
            row = {"model": model, "temperature": t, "top_k": k, "top_p": p,
                   "prompt_id": pr["id"], "category": pr["category"], "type": pr["type"],
                   "run": run, "error": ""}
            try:
                text, n, tps, lat = ask(client, model, pr["prompt"], t, k, p)
                row.update(response=text, eval_tokens=n, tokens_per_sec=tps, latency_s=lat)
                call_time += lat
            except Exception as e:
                errors += 1
                row.update(response="", eval_tokens=0, tokens_per_sec=0, latency_s=0, error=str(e)[:200])
            writer.writerow(row)
            f.flush()
    except KeyboardInterrupt:
        print("\nStopped. Progress is saved - run the same command again to continue.")
    finally:
        f.close()

    elapsed = time.perf_counter() - t0
    print(f"\nDone in {elapsed / 60:.1f} min. Errors: {errors}")
    if args.pilot and len(todo):
        per_call = call_time / len(todo)
        full = len(config.MODELS) * len(config.all_settings()) * len(config.PROMPTS) * config.REPEATS
        print(f"Average {per_call:.1f} s per call -> full run of {full} calls "
              f"will take about {per_call * full / 3600:.1f} hours on this computer.")


if __name__ == "__main__":
    main()
