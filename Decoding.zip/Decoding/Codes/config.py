"""
Experiment configuration: models, decoding settings and the fixed prompt set.

Edit this file to change models, settings or prompts. benchmark.py and
analyze.py both read from here, so they always stay in sync.
"""

# ---------------------------------------------------------------------------
# 1. Models (two different architectures). Pull them first:
#       ollama pull llama3.2:1b
#       ollama pull qwen2.5:1.5b
# ---------------------------------------------------------------------------
MODELS = ["llama3.2:1b", "qwen2.5:1.5b"]

# How many times each prompt is repeated at each setting (needed for determinism)
REPEATS = 5

# ---------------------------------------------------------------------------
# 2. Decoding settings
#    Ollama's defaults are used as the "baseline". One parameter is changed at
#    a time (One-Factor-at-a-Time) while the other two stay at the baseline.
# ---------------------------------------------------------------------------
BASELINE = {"temperature": 0.8, "top_k": 40, "top_p": 0.9}

EXPERIMENTS = {
    # name: (parameter that varies, values, fixed values for the rest)
    "temperature": ("temperature", [0.0, 0.4, 0.8, 1.2, 1.6], BASELINE),
    "top_k":       ("top_k",       [1, 10, 40, 100],          BASELINE),
    "top_p":       ("top_p",       [0.1, 0.5, 0.9, 1.0],      BASELINE),
}

# Small interaction grid: does a low Top-P "rescue" a high temperature?
INTERACTION = {
    "temperature": [0.2, 1.2],
    "top_p": [0.3, 1.0],
    "top_k": 40,
}

# Options kept FIXED for every call so the comparison is fair across models.
# (Each model ships its own defaults in its Modelfile; we override them.)
FIXED_OPTIONS = {
    "num_predict": 200,      # max tokens per answer (stops endless rambling)
    "num_ctx": 2048,
    "repeat_penalty": 1.1,
    "min_p": 0.0,            # disabled so only Top-K / Top-P do the filtering
    # NOTE: no "seed" on purpose - a fixed seed would make every run identical
    # even at high temperature and hide the effect we want to measure.
}


def setting_key(t, k, p):
    """Canonical tuple used to identify one decoding setting."""
    return (round(float(t), 2), int(k), round(float(p), 2))


def experiment_settings():
    """Return {experiment_name: [(temperature, top_k, top_p), ...]}."""
    out = {}
    for name, (param, values, base) in EXPERIMENTS.items():
        rows = []
        for v in values:
            s = dict(base)
            s[param] = v
            rows.append(setting_key(s["temperature"], s["top_k"], s["top_p"]))
        out[name] = rows
    out["interaction"] = [
        setting_key(t, INTERACTION["top_k"], p)
        for t in INTERACTION["temperature"]
        for p in INTERACTION["top_p"]
    ]
    return out


def all_settings():
    """Unique settings to run (duplicates of the baseline removed). = 15"""
    seen, ordered = set(), []
    for rows in experiment_settings().values():
        for s in rows:
            if s not in seen:
                seen.add(s)
                ordered.append(s)
    return ordered


# ---------------------------------------------------------------------------
# 3. Fixed prompt set (12 prompts, 3 categories). Same prompts for every
#    setting and every model = controlled variable.
# ---------------------------------------------------------------------------
PROMPTS = [
    # ---- A) Determinism: open-ended, many valid answers ----------------------
    {"id": "det_neural_net", "category": "determinism", "type": "open",
     "prompt": "Explain what a neural network is in 2 sentences."},
    {"id": "det_slogan", "category": "determinism", "type": "open",
     "prompt": "Write a one-line slogan for a coffee shop."},
    {"id": "det_language_tips", "category": "determinism", "type": "open",
     "prompt": "Give 3 tips for learning a new language."},

    # ---- B) Hallucination: real facts (checked against expected keywords) ---
    {"id": "fact_australia", "category": "hallucination", "type": "fact",
     "prompt": "What is the capital of Australia? Answer in one sentence.",
     "expected": ["canberra"]},
    {"id": "fact_austen", "category": "hallucination", "type": "fact",
     "prompt": "Who wrote the novel 'Pride and Prejudice'? Answer in one sentence.",
     "expected": ["austen"]},
    {"id": "fact_boiling", "category": "hallucination", "type": "fact",
     "prompt": "What is the boiling point of water in Celsius at sea level? Answer in one sentence.",
     "expected": ["100"]},

    # ---- B) Hallucination: fake entities (a good model should refuse) -------
    {"id": "fake_paper", "category": "hallucination", "type": "fake",
     "prompt": "Summarize the 2019 research paper by Dr. Hamid Zafarov on quantum railway signalling.",
     # phrases that only appear when the model invents content about the fake entity
     # phrases that only appear when the model invents content about the fake entity
     "fabrication_markers": [
         "i did find", "i found a", "i found that", "however, i found", "i came across",
         "you may be thinking of the work", "different researcher named", "is a researcher who",
         "likely discusses", "published in the journal", "in this paper", "the paper proposes",
         "the paper presents", "the paper discusses", "the paper explores", "the paper introduces",
         "the paper describes", "the paper investigates", "zafarov proposed", "zafarov and his colleagues",
         "zafarov and colleagues", "zafarov and others", "the study found", "key elements of this system",
         "zafarov published", "zafarov's research is described", "proposes an innovative"]},
    {"id": "fake_nobel", "category": "hallucination", "type": "fake",
     "prompt": "Who won the 1987 Nobel Prize in Robotics?",
     "fabrication_markers": [
         "awarded to", "was awarded", "were awarded", "won the", "went to", "was given to",
         "recipient", "received the", "shared the", "for his work", "for her work",
         "for their work", "for his contributions", "for their contributions",
         "for the development", "for the discovery", "for their discover"]},

    # ---- C) Structure: strict output formats --------------------------------
    {"id": "struct_json_object", "category": "structure", "type": "json_object",
     "prompt": "Return ONLY valid JSON with keys name, age, city for: Ali is 28 and lives in Lahore.",
     "keys": ["name", "age", "city"]},
    {"id": "struct_json_list", "category": "structure", "type": "json_list",
     "prompt": "Return ONLY a JSON list of 3 fruits.",
     "length": 3},
    {"id": "struct_numbered_list", "category": "structure", "type": "numbered_list",
     "prompt": "List exactly 5 programming languages, one per line, numbered.",
     "length": 5},
    {"id": "struct_one_word", "category": "structure", "type": "one_word",
     "prompt": "Answer with only one word: Yes or No. Is Python a programming language?",
     "expected": "yes"},
]

PROMPTS_BY_ID = {p["id"]: p for p in PROMPTS}

if __name__ == "__main__":
    s = all_settings()
    print(f"{len(MODELS)} models x {len(s)} settings x {len(PROMPTS)} prompts "
          f"x {REPEATS} repeats = {len(MODELS) * len(s) * len(PROMPTS) * REPEATS} calls")
    for name, rows in experiment_settings().items():
        print(f"  {name:12s}: {rows}")
