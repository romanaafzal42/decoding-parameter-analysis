"""
Create a readable preview of the real model answers, organised by experiment
and by every value of Temperature, Top-K and Top-P.

For each value it shows:
  - Determinism   : how many different answers out of 5, similarity, and the 5 slogan answers
  - Hallucination : real-fact results and the answers to the two fake questions (with labels)
  - Structure     : strict / lenient results and one example output per question
  - Observation   : a short summary calculated from the data

Usage:
    python make_examples.py                 # -> results/answer_examples.md

Reads results/scored_results.csv (created by analyze.py), so run analyze.py first.
Open the file in VS Code and press Ctrl+Shift+V to see it nicely.
"""

import argparse
import os

import pandas as pd

import config
import metrics

LABEL_TEXT = {
    "admitted_unknown": "✅ says it does not exist",
    "generic_refusal": "⚪ refuses to answer",
    "mixed": "🟡 says it does not exist but makes up other facts",
    "fabricated": "🔴 makes up an answer",
}
EXPERIMENT_TITLES = {
    "temperature": ("Temperature", "temperature", "Top-K 40, Top-P 0.9"),
    "top_k": ("Top-K", "top_k", "Temperature 0.8, Top-P 0.9"),
    "top_p": ("Top-P", "top_p", "Temperature 0.8, Top-K 40"),
}


def short(text, n=220):
    t = " ".join(str(text).split()).replace("|", "\\|").replace("`", "\\`")
    return t if len(t) <= n else t[:n].rstrip() + " …"


def name(model):
    return "Llama 3.2" if model.startswith("llama") else "Qwen 2.5" if model.startswith("qwen") else model


def group(df, model, pid, s):
    t, k, p = s
    g = df[(df.model == model) & (df.prompt_id == pid) & (df.temperature == t)
           & (df.top_k == k) & (df.top_p == p)]
    return g.sort_values("run")


def det(df, model, pid, s):
    g = group(df, model, pid, s)
    return metrics.determinism_scores(g["response"].tolist()) if len(g) else None


def setting_rows(df, model, s):
    t, k, p = s
    return df[(df.model == model) & (df.temperature == t) & (df.top_k == k) & (df.top_p == p)]


def pct(x):
    return f"{100 * x:.0f}%"


# --------------------------------------------------------------------------
def overview(df, models, out):
    n_settings = sum(len(v) for k, v in config.experiment_settings().items() if k != "interaction")
    out.append("## Question set\n")
    out.append("Each category has more than one question (12 in total). Every question was asked "
               f"**{config.REPEATS} times** at every setting to both models.\n")
    out.append("| # | Category | Question |\n|---|---|---|")
    for i, p in enumerate(config.PROMPTS, 1):
        cat = p["category"].title() + (" (real fact)" if p["type"] == "fact" else
                                       " (fake)" if p["type"] == "fake" else "")
        out.append(f"| {i} | {cat} | {p['prompt']} |")
    out.append("")
    out.append("**Contents**\n")
    for exp, (title, _, fixed) in EXPERIMENT_TITLES.items():
        vals = ", ".join(str(v) for v in config.EXPERIMENTS[exp][1])
        out.append(f"- Experiment: **{title}** = {vals} ({fixed})")
    out.append("")


def experiment_summary(df, models, exp, settings, out):
    title, param, fixed = EXPERIMENT_TITLES[exp]
    out.append(f"### Summary of all {title} values\n")
    out.append(f"| {title} | Model | Similarity (1.00 = same) | Different answers of 5 | "
               "Real facts correct | Hallucination (fake questions) | Strict structure | Lenient structure |")
    out.append("|---|---|---|---|---|---|---|---|")
    for s in settings:
        v = dict(zip(("temperature", "top_k", "top_p"), s))[param]
        for model in models:
            g = setting_rows(df, model, s)
            sims = [det(df, model, p["id"], s) for p in config.PROMPTS if p["category"] == "determinism"]
            sim = sum(d["mean_similarity"] for d in sims) / len(sims)
            uniq = sum(d["unique_answers"] for d in sims) / len(sims)
            fact = g.loc[g.type == "fact", "fact_correct"].astype(float).mean()
            hall = g.loc[g.type == "fake", "hallucinated"].astype(float).mean()
            st = g.loc[g.category == "structure", "struct_strict"].astype(float).mean()
            le = g.loc[g.category == "structure", "struct_lenient"].astype(float).mean()
            out.append(f"| {v} | {name(model)} | {sim:.2f} | {uniq:.1f} | {pct(fact)} | {pct(hall)} | {pct(st)} | {pct(le)} |")
    out.append("")


def setting_section(df, models, exp, s, out):
    title, param, fixed = EXPERIMENT_TITLES[exp]
    v = dict(zip(("temperature", "top_k", "top_p"), s))[param]
    out.append(f"### {title} = {v}\n")
    out.append(f"*Setting: temperature={s[0]}, top_k={s[1]}, top_p={s[2]}*\n")

    # ---- Determinism
    out.append("#### Determinism\n")
    out.append("| Question | " + " | ".join(name(m) for m in models) + " |")
    out.append("|---|" + "---|" * len(models))
    for p in [p for p in config.PROMPTS if p["category"] == "determinism"]:
        cells = []
        for m in models:
            d = det(df, m, p["id"], s)
            cells.append(f"{d['unique_answers']} unique answer(s) of 5, similarity {d['mean_similarity']:.2f}")
        out.append(f"| {p['prompt']} | " + " | ".join(cells) + " |")
    out.append("")
    out.append("The 5 answers to *\"Write a one-line slogan for a coffee shop.\"*\n")
    out.append("| Run | " + " | ".join(name(m) for m in models) + " |")
    out.append("|---|" + "---|" * len(models))
    gs = {m: group(df, m, "det_slogan", s)["response"].tolist() for m in models}
    for i in range(config.REPEATS):
        out.append(f"| {i + 1} | " + " | ".join(short(gs[m][i], 150) if i < len(gs[m]) else "" for m in models) + " |")
    out.append("")

    # ---- Hallucination
    out.append("#### Hallucination\n")
    out.append("| Real-fact question | " + " | ".join(name(m) for m in models) + " |")
    out.append("|---|" + "---|" * len(models))
    for p in [p for p in config.PROMPTS if p["type"] == "fact"]:
        cells = []
        for m in models:
            g = group(df, m, p["id"], s)
            cells.append(f"{int(g['fact_correct'].astype(float).sum())}/5 correct")
        out.append(f"| {p['prompt']} | " + " | ".join(cells) + " |")
    out.append("")
    out.append("| Fake question | Model | Result of the 5 answers | Example answer (run 1) |\n|---|---|---|---|")
    for p in [p for p in config.PROMPTS if p["type"] == "fake"]:
        for m in models:
            g = group(df, m, p["id"], s)
            counts = g["fake_outcome"].value_counts()
            res = ", ".join(f"{counts[o]}× {LABEL_TEXT[o]}" for o in metrics.FAKE_OUTCOMES if o in counts)
            out.append(f"| {p['prompt']} | {name(m)} | {res} | {short(g['response'].iloc[0])} |")
    out.append("")

    # ---- Structure
    out.append("#### Structure\n")
    out.append("| Question | Model | Strict | Lenient | Example output (run 1) |\n|---|---|---|---|---|")
    for p in [p for p in config.PROMPTS if p["category"] == "structure"]:
        for m in models:
            g = group(df, m, p["id"], s)
            st = int(g["struct_strict"].astype(float).sum())
            le = int(g["struct_lenient"].astype(float).sum())
            out.append(f"| {p['prompt']} | {name(m)} | {st}/5 | {le}/5 | {short(g['response'].iloc[0], 160)} |")
    out.append("")

    # ---- Observation
    lines = []
    for m in models:
        g = setting_rows(df, m, s)
        sims = [det(df, m, p["id"], s) for p in config.PROMPTS if p["category"] == "determinism"]
        sim = sum(d["mean_similarity"] for d in sims) / len(sims)
        hall = g.loc[g.type == "fake", "hallucinated"].astype(float).mean()
        st = g.loc[g.category == "structure", "struct_strict"].astype(float).mean()
        le = g.loc[g.category == "structure", "struct_lenient"].astype(float).mean()
        kind = ("the same answer every time" if sim >= 0.95 else
                "mostly similar answers" if sim >= 0.6 else "different answers each time")
        hp = int(group(df, m, "fake_paper", s)["hallucinated"].astype(float).sum())
        hn = int(group(df, m, "fake_nobel", s)["hallucinated"].astype(float).sum())
        lines.append(f"{name(m)} gave {kind} (similarity {sim:.2f}). It hallucinated in {pct(hall)} of the "
                     f"fake-question answers (paper {hp}/5, Nobel {hn}/5) and followed the exact format in "
                     f"{pct(st)} of the structure answers (right content in {pct(le)}).")
    out.append("> **Observation:** " + " ".join(lines) + "\n")


def experiment_observation(df, models, exp, settings, out):
    title, param, _ = EXPERIMENT_TITLES[exp]
    first, last = settings[0], settings[-1]
    vf = dict(zip(("temperature", "top_k", "top_p"), first))[param]
    vl = dict(zip(("temperature", "top_k", "top_p"), last))[param]
    lines = []
    for m in models:
        def sim(s):
            ds = [det(df, m, p["id"], s) for p in config.PROMPTS if p["category"] == "determinism"]
            return sum(d["mean_similarity"] for d in ds) / len(ds)
        halls = [setting_rows(df, m, s).query("type == 'fake'")["hallucinated"].astype(float).mean() for s in settings]
        lines.append(f"{name(m)}: similarity went from {sim(first):.2f} ({title} {vf}) to {sim(last):.2f} "
                     f"({title} {vl}); hallucination stayed between {pct(min(halls))} and {pct(max(halls))}.")
    lines.append(f"So {title} mainly changes how repeatable the answers are. It does not clearly change "
                 "hallucination or structure.")
    out.append(f"> **Overall observation for {title}:** " + " ".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="results/scored_results.csv")
    ap.add_argument("--out", default="results/answer_examples.md")
    args = ap.parse_args()

    df = pd.read_csv(args.input, keep_default_na=False, na_values=[""])
    df["temperature"] = df["temperature"].astype(float).round(2)
    df["top_p"] = df["top_p"].astype(float).round(2)
    df["top_k"] = df["top_k"].astype(int)
    df["run"] = df["run"].astype(int)
    df["response"] = df["response"].fillna("").astype(str)
    models = [m for m in config.MODELS if m in df["model"].unique()]
    exps = config.experiment_settings()

    out = ["# Example answers for every setting\n",
           "Real answers from the benchmark (not edited; long answers are shortened with \"…\"). "
           "For every value of Temperature, Top-K and Top-P you can see determinism, hallucination and "
           "structure. All answers are in `raw_results.csv`.\n"]
    overview(df, models, out)
    for n, exp in enumerate(("temperature", "top_k", "top_p"), start=1):
        title, _, fixed = EXPERIMENT_TITLES[exp]
        out.append(f"## Experiment {n}: {title} ({fixed})\n")
        experiment_summary(df, models, exp, exps[exp], out)
        experiment_observation(df, models, exp, exps[exp], out)
        for s in exps[exp]:
            setting_section(df, models, exp, s, out)

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print(f"Written: {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
