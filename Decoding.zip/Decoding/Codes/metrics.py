"""
Scoring functions: turn each raw model answer into numbers.

  Determinism   -> unique answers + mean pairwise similarity across repeats
  Hallucination -> factual accuracy (keyword match) and refusal on fake questions
  Structure     -> strict format compliance and lenient (content-only) compliance

All checks are automatic heuristics; analyze.py also exports a random sample
for manual verification (recommended for the report).
"""

import itertools
import json
import re
from difflib import SequenceMatcher

import config

# Phrases that indicate the model refused / said the entity does not exist.
REFUSAL_MARKERS = [
    "no such", "does not exist", "doesn't exist", "did not exist", "not exist",
    "there is no", "there's no", "there was no", "no nobel prize in robotics",
    "not aware", "no record", "no information", "no known", "no evidence",
    "couldn't find", "could not find", "can't find", "cannot find", "unable to find",
    "not able to find", "unable to locate", "not familiar", "i'm not sure",
    "fictional", "fictitious", "not a real", "doesn't appear", "does not appear",
    "never been awarded", "not awarded", "isn't a nobel", "is not a nobel",
    "i don't have", "i do not have", "not have access", "no publicly available",
    "may not exist", "might not exist", "unable to verify", "cannot verify",
    "can't verify", "not been able to", "no category", "there were no", "there has been no",
    "there hasn't been", "did not exist", "did not win a nobel", "not a robotics prize",
    "not related to robotics", "not directly related to robotics", "unrelated to the topic of robotics",
    "not for robotics", "rather than robotics", "rather than winning the nobel prize in robotics",
    "does not pertain to robotics", "not awarded for work related to robotics",
    "not recognized with a nobel prize in robotics", "not directly involved in the field of robotics",
    "did not mention robotics", "did not go to any individual", "not robotics specialists",
    "not specifically to robotics", "not specifically involve robotics", "no direct connection",
    "no specific award related to robotics", "not awarded in robotics", "no mention of a nobel prize in robotics",
    "\u4e0e\u673a\u5668\u4eba",  # Chinese: "...with robotics" (e.g. "has nothing to do with robotics")
]


def normalize(text):
    return " ".join(str(text).split())


# ---------------------------------------------------------------------------
# Determinism (computed per group of repeats)
# ---------------------------------------------------------------------------
def determinism_scores(responses):
    """responses: list of answers to the SAME prompt at the SAME setting."""
    norm = [normalize(r) for r in responses]
    n = len(norm)
    unique = len(set(norm))
    most_common = max(norm.count(x) for x in set(norm)) if n else 0
    pairs = list(itertools.combinations(norm, 2))
    sim = (sum(SequenceMatcher(None, a, b).ratio() for a, b in pairs) / len(pairs)) if pairs else 1.0
    return {
        "n_runs": n,
        "unique_answers": unique,
        "exact_match_rate": most_common / n if n else 0.0,  # share of runs equal to the most common answer
        "mean_similarity": sim,                             # 1.0 = identical, 0 = completely different
    }


# ---------------------------------------------------------------------------
# Hallucination
# ---------------------------------------------------------------------------
# Generic "I won't answer" refusals (not hallucination, but not informative either)
GENERIC_REFUSAL_MARKERS = [
    "can't assist", "cannot assist", "can not assist", "unable to assist",
    "can't help with", "cannot help with", "i'm sorry, but i can", "i am sorry, but i can",
    "can't provide", "cannot provide", "not able to provide", "can't fulfill", "cannot fulfill",
    "copyright", "unable to engage", "political", "unable to summarize", "can't summarize",
    "cannot summarize", "not able to summarize", "not able to access", "need more information",
    "inappropriate channel", "not able to provide information", "do not have access to real-time",
]

FAKE_OUTCOMES = ["admitted_unknown", "generic_refusal", "mixed", "fabricated"]


def _clean(text):
    return normalize(text).lower().replace("\u2019", "'")


def is_refusal(text):
    t = _clean(text)
    return any(m in t for m in REFUSAL_MARKERS + GENERIC_REFUSAL_MARKERS)


def classify_fake(text, prompt):
    """Classify an answer to a question about a NON-EXISTENT entity.

    admitted_unknown : says it does not exist / no information        -> correct
    generic_refusal  : "I'm sorry, I can't assist with that"          -> safe, uninformative
    mixed            : rejects the premise BUT also invents facts     -> partial hallucination
    fabricated       : answers as if the entity were real             -> hallucination
    """
    t = _clean(text)
    admits = any(m in t for m in REFUSAL_MARKERS)
    generic = any(m in t for m in GENERIC_REFUSAL_MARKERS)
    invents = any(m in t for m in prompt.get("fabrication_markers", []))
    if admits or generic:
        if invents:
            return "mixed"
        return "admitted_unknown" if admits else "generic_refusal"
    return "fabricated"


def score_fact(text, expected):
    t = normalize(text).lower()
    return int(any(e in t for e in expected))


# ---------------------------------------------------------------------------
# Structure
# ---------------------------------------------------------------------------
_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.S | re.I)


def _lenient_json(text):
    """Try to parse JSON even if wrapped in ``` fences or extra words."""
    t = text.strip()
    m = _FENCE.search(t)
    if m:
        t = m.group(1).strip()
    try:
        return json.loads(t)
    except Exception:
        pass
    for open_c, close_c in (("{", "}"), ("[", "]")):
        i, j = t.find(open_c), t.rfind(close_c)
        if i != -1 and j > i:
            try:
                return json.loads(t[i:j + 1])
            except Exception:
                continue
    return None


def _strict_json(text):
    try:
        return json.loads(text.strip())
    except Exception:
        return None


def score_structure(text, prompt):
    """Return (strict_ok, lenient_ok).

    strict  = output is EXACTLY the requested format, nothing extra.
    lenient = the requested content is there, even with extra text or fences.
    """
    kind = prompt["type"]
    if kind == "json_object":
        keys = set(prompt["keys"])
        s, l = _strict_json(text), _lenient_json(text)
        ok = lambda o: isinstance(o, dict) and keys.issubset(o.keys())
        return int(ok(s)), int(ok(l))
    if kind == "json_list":
        n = prompt["length"]
        s, l = _strict_json(text), _lenient_json(text)
        ok = lambda o: isinstance(o, list) and len(o) == n
        return int(ok(s)), int(ok(l))
    if kind == "numbered_list":
        n = prompt["length"]
        lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
        numbered = [ln for ln in lines if re.match(r"^\**\d+[.)]\s*\S", ln)]
        return int(len(numbered) == n and len(lines) == n), int(len(numbered) == n)
    if kind == "one_word":
        t = text.strip().lower().strip(".!*\"' ")
        return int(t == prompt["expected"]), int(t.startswith(prompt["expected"]))
    raise ValueError(kind)


# ---------------------------------------------------------------------------
def score_row(row):
    """Add per-answer scores to one raw result row (dict-like)."""
    pr = config.PROMPTS_BY_ID[row["prompt_id"]]
    text = "" if row["response"] is None else str(row["response"])
    out = {"fact_correct": None, "fake_outcome": None, "refused": None, "hallucinated": None,
           "struct_strict": None, "struct_lenient": None,
           "words": len(text.split())}
    if pr["type"] == "fact":
        out["fact_correct"] = score_fact(text, pr["expected"])
    elif pr["type"] == "fake":
        outcome = classify_fake(text, pr)
        out["fake_outcome"] = outcome
        # hallucination = any invented content (fully fabricated OR mixed)
        out["hallucinated"] = int(outcome in ("fabricated", "mixed"))
        out["refused"] = 1 - out["hallucinated"]
    elif pr["category"] == "structure":
        out["struct_strict"], out["struct_lenient"] = score_structure(text, pr)
    return out
